﻿using Microsoft.EntityFrameworkCore;
using SuperHeroAPI_DotNet8.Entity;


namespace SuperHeroAPI_DotNet8.NewFolder
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        { 
        
        
        }
        public DbSet<Superhero> MyProperty {  get; set; }

    }
}
