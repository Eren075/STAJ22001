﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SuperHeroAPI_DotNet8.Entity;
using SuperHeroAPI_DotNet8.NewFolder;
using Microsoft.EntityFrameworkCore;
using System.Drawing.Text;

namespace SuperHeroAPI_DotNet8.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SuperHeroController : ControllerBase
    {
        private readonly DataContext _context;

        public SuperHeroController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<Superhero>>> GetAllHeroes() 
        {

            var heroes = await _context.MyProperty.ToListAsync();
            return Ok(heroes);
        }
        [HttpGet("{id}")]
        
        public async Task<ActionResult<Superhero>> GetHero(int id)
        {

            var hero = await _context.MyProperty.FindAsync(id);
            if (hero is null)
            {
                return BadRequest("Hero not found");


            }
            return Ok(hero);
            
        }
        [HttpPost]

        public async Task<ActionResult<List<Superhero>>> Addhero(Superhero hero)
        {

            _context.MyProperty.Add(hero);
            await _context.SaveChangesAsync();
            return Ok(await _context.MyProperty.ToListAsync());
            

        }
        [HttpPut]
        public async Task<ActionResult<List<Superhero>>> Updatehero( Superhero updatedhero)
        {

            var dbhero = await _context.MyProperty.FindAsync(updatedhero.Id);
            if (dbhero is null)
            {
                return BadRequest("Hero not found");


            }
            
            dbhero.Name = updatedhero.Name;
            dbhero.FirstName = updatedhero.FirstName;
            dbhero.LastName = updatedhero.LastName;
            dbhero.Place = updatedhero.Place;
            await _context.SaveChangesAsync();
            return Ok(await _context.MyProperty.ToListAsync());


        }
        [HttpDelete]
        public async Task<ActionResult<List<Superhero>>> Deletehero(int id)
        {

            var dbhero = await _context.MyProperty.FindAsync(id);
            if (dbhero is null)
            {
                return BadRequest("Hero not found");


            }

            _context.MyProperty.Remove(dbhero);
            await _context.SaveChangesAsync();
            return Ok(await _context.MyProperty.ToListAsync());


        }
    }
}
