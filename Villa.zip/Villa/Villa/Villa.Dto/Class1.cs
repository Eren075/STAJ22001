﻿namespace Villa.Dto
{
    public class Class1
    {

    }
}
