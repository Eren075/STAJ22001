﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Villa.Entity.Entities;

namespace Villa.Business.Validators
{
    public class SubHeaderValidator:AbstractValidator<SubHeader>
    {
        public SubHeaderValidator() 
        {
            RuleFor(x => x.Address).NotEmpty().WithMessage("Adres Boş Bırakılamaz.");
            RuleFor(x => x.Email).NotEmpty().WithMessage("Email Boş Bırakılamaz.");
            RuleFor(x => x.Facebook).NotEmpty().WithMessage("Facebook Boş Bırakılamaz.");
            RuleFor(x => x.Twitter).NotEmpty().WithMessage("Twitter Boş Bırakılamaz.");
            RuleFor(x => x.Linkedin).NotEmpty().WithMessage("Linkedin Boş Bırakılamaz.");
            RuleFor(x => x.Instagram).NotEmpty().WithMessage("Instagram Boş Bırakılamaz.");


        }
    }
}
