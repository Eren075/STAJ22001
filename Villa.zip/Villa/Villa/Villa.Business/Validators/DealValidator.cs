﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Villa.Entity.Entities;

namespace Villa.Business.Validators
{
    public class DealValidator: AbstractValidator<Deal>
    {
        public DealValidator() {
            RuleFor(x => x.Type).NotEmpty().WithMessage("İlan Türü Boş Bırakılamaz.");
            RuleFor(x => x.ImageUrl).NotEmpty().WithMessage("Resim Url Boş Bırakılamaz.");
            RuleFor(x => x.Title).NotEmpty().WithMessage("Başlık Boş Bırakılamaz.");
            RuleFor(x => x.Description).NotEmpty().WithMessage("Açıklama Boş Bırakılamaz.");
            RuleFor(x => x.Square).NotEmpty().WithMessage("m2 Boş Bırakılamaz.");
            RuleFor(x => x.Floor).NotEmpty().WithMessage("Kat Boş Bırakılamaz.");
            RuleFor(x => x.RoomCount).NotEmpty().WithMessage("Oda Boş Bırakılamaz.");
            
            RuleFor(x => x.PaymentType).NotEmpty().WithMessage("Ödeme Boş Bırakılamaz.");
        }
    
    }
}
