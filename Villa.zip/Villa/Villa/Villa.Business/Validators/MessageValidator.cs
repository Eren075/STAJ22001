﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Villa.Entity.Entities;

namespace Villa.Business.Validators
{
    public class MessageValidator: AbstractValidator<Message>
    {
        public MessageValidator() {
            RuleFor(x => x.Name).NotEmpty().WithMessage("Ad Soyad Boş Bırakılamaz.");
            RuleFor(x => x.Email).NotEmpty().WithMessage("Email  Boş Bırakılamaz.");
            RuleFor(x => x.Subject).NotEmpty().WithMessage("Konu Boş Bırakılamaz.");
            RuleFor(x => x.MessageContent).NotEmpty().WithMessage(" Boş Bırakılamaz.");
        }
    }
}
