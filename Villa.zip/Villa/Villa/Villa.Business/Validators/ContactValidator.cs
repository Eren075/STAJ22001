﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Villa.Entity.Entities;

namespace Villa.Business.Validators
{
    public class ContactValidator: AbstractValidator<Contact>
    {
        public ContactValidator() {
            RuleFor(x => x.MapUrl).NotEmpty().WithMessage("Harita Boş Bırakılamaz.");
            RuleFor(x => x.Phone).NotEmpty().WithMessage("Telefon Boş Bırakılamaz.");
            RuleFor(x => x.Email).NotEmpty().WithMessage("Email Boş Bırakılamaz.");
           
        }
    }
}
