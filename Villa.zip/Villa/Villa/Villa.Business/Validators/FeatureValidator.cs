﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Villa.Entity.Entities;

namespace Villa.Business.Validators
{
    public class FeatureValidator:AbstractValidator<Feature>
    {
        public FeatureValidator() {
            RuleFor(x => x.ImageUrl).NotEmpty().WithMessage("Resim Url Boş Bırakılamaz.");
            RuleFor(x => x.Title).NotEmpty().WithMessage("Başlık Boş Bırakılamaz.");
            RuleFor(x => x.SubTitle).NotEmpty().WithMessage("Alt Başlık Boş Bırakılamaz.");
            RuleFor(x => x.Square).NotEmpty().WithMessage("m2 Boş Bırakılamaz.");
            RuleFor(x => x.Contract).NotEmpty().WithMessage("Kontrat Türü Boş Bırakılamaz.");
            RuleFor(x => x.Payment).NotEmpty().WithMessage("Ödeme Türü Boş Bırakılamaz.");
            RuleFor(x => x.Safety).NotEmpty().WithMessage("Güvenlik Boş Bırakılamaz.");

        }
     
    }
}
