﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Villa.Entity.Entities;

namespace Villa.Business.Validators
{
    public class ProductValidator: AbstractValidator<Product>
    {
        public ProductValidator() {

            RuleFor(x => x.ImageUrl).NotEmpty().WithMessage("Resim  Boş Bırakılamaz.");
            RuleFor(x => x.Price).NotEmpty().WithMessage("Başlık  Boş Bırakılamaz.");
            RuleFor(x => x.Title).NotEmpty().WithMessage("Fiyat  Boş Bırakılamaz.");
            RuleFor(x => x.BedroomCount).NotEmpty().WithMessage("Oda Sayısı Boş Bırakılamaz.");
            RuleFor(x => x.BathroomCount).NotEmpty().WithMessage("Banyo Sayısı Boş Bırakılamaz.");
            RuleFor(x => x.Area).NotEmpty().WithMessage("MetreKare Bilgisi  Boş Bırakılamaz.");
            RuleFor(x => x.Floor).NotEmpty().WithMessage("Kaçıncı Kat Bilgisi  Boş Bırakılamaz.");
            RuleFor(x => x.ParkingCount).NotEmpty().WithMessage("Park Alanı Boş Bırakılamaz.");


        }
    }
}
