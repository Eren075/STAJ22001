﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Villa.Entity.Entities;

namespace Villa.Business.Validators
{
    public class BannerValidator: AbstractValidator<Banner>
    {
        public BannerValidator() {
        RuleFor(x=>x.City).NotEmpty().WithMessage("Şehir Boş Bırakılamaz.");
        RuleFor(x=>x.Title).NotEmpty().WithMessage("Başlık Boş Bırakılamaz.");
        RuleFor(x=>x.ImageUrl).NotEmpty().WithMessage("Resim Boş Bırakılamaz."); 
        }
    }
}
