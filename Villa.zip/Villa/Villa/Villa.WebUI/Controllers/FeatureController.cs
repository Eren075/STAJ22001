﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using Villa.Business.Abstract;
using Villa.Business.Validators;
using Villa.Dto.Dtos.DealDtos;
using Villa.Dto.Dtos.FeatureDtos;
using Villa.Entity.Entities;

namespace Villa.WebUI.Controllers
{
    public class FeatureController : Controller
    {
        private readonly IFeatureService _featureService;
        private readonly IMapper _mapper;

        public FeatureController(IFeatureService featureService, IMapper mapper)
        {
            _featureService = featureService;
            _mapper = mapper;
        }

        public async Task<IActionResult> Index()
        {
            var values = await _featureService.TGetListAsync();
            var FeatureList = _mapper.Map<List<ResultFeatureDto>>(values);
            return View(FeatureList);
        }
        public async Task<IActionResult> DeleteFeature(ObjectId id)
        {
            await _featureService.TDeleteAsync(id);
            return RedirectToAction("Index");
        }
        public IActionResult CreateFeature()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> CreateFeature(CreateFeatureDto createfeatureDto)
        {
            ModelState.Clear();
            var newfeature = _mapper.Map<Feature>(createfeatureDto);
            var validator = new FeatureValidator();
            var result = validator.Validate(newfeature);
            if (!result.IsValid)
            {
                result.Errors.ForEach(x =>
                {
                    ModelState.AddModelError(x.PropertyName, x.ErrorMessage);
                });
                return View();

            }
            await _featureService.TCreateAsync(newfeature);
            return RedirectToAction("Index");
        }
        public async Task<IActionResult> UpdateFeature(ObjectId id)
        {
            var value = await _featureService.TGetByIdAsync(id);
            var feature = _mapper.Map<UpdateFeatureDto>(value);
            return View(feature);
        }
        [HttpPost]
        public async Task<IActionResult> UpdateFeature(UpdateFeatureDto updatefeatureDto)
        {
            var feature = _mapper.Map<Feature>(updatefeatureDto);
            await _featureService.TUpdateAsync(feature);
            return RedirectToAction("Index");
        }
    }
}
