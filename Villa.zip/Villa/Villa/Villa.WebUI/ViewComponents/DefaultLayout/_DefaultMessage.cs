﻿using Microsoft.AspNetCore.Mvc;

namespace Villa.WebUI.ViewComponents.DefaultLayout
{
    public class _DefaultMessage:ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            return View();
        }
    }
}
